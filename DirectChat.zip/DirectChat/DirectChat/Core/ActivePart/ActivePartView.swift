//
//  ActivePartView.swift
//  DirectChat
//
//  Created by user on 13/12/2023.
//

import SwiftUI

struct ActivePartView: View {
    var body: some View {
        /**ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 30) {
                ForEach(0 ... 10, id: \.self) { user in
                    VStack {
                        ZStack(alignment: .bottomTrailing) {
                            Image(systemName: "person.circle.fill")
                                .resizable()
                                .frame(width: 63, height: 63)
                                .foregroundColor(Color(.systemGray3))
                            
                            ZStack {
                                Circle()
                                    .fill(.white)
                                    .frame(width: 19, height: 19)
                                Circle()
                                    .fill(Color(.systemGreen))
                                    .frame(width: 14, height: 14)
                            }
                        }
                        
                        Text("Lucas")
                            .font(.subheadline)
                            .foregroundColor(.brown)
                    }
                }
            }
            .padding()
        }
        .frame(height: 110)**/
        Spacer()
    }
}

#Preview {
    ActivePartView()
}
