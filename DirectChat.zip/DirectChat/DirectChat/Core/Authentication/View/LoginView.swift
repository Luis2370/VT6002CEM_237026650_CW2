//
//  LoginView.swift
//  DirectChat
//
//  Created by user on 13/12/2023.
//

import SwiftUI

struct LoginView: View {
    @StateObject var viewModel = LoginViewModel()
    var body: some View {
        NavigationStack {
            VStack {
                Spacer()
                
                Image(systemName: "ellipsis.message")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 200, height: 200)
                    .foregroundColor(.brown)
                    .padding()
                
                VStack(spacing: 16) {
                    TextField("Email", text: $viewModel.email)
                        .font(.subheadline)
                        .padding(13)
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                        .padding(.horizontal, 25)
                    SecureField("Password", text: $viewModel.password)
                        .font(.subheadline)
                        .padding(13)
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                        .padding(.horizontal, 25)
                }
                
                
                Button {
                    print("Forgot password")
                } label: {
                    Text("Forgot password?")
                        .font(.footnote)
                        .fontWeight(.semibold)
                        .foregroundColor(.brown)
                        .padding(.top)
                        .padding(.trailing, 28)
                }
                .frame(maxWidth: .infinity, alignment: .trailing)

                Button {
                    Task { try await viewModel.login() }
                } label: {
                    Text("Login")
                        .font(.subheadline)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .frame(width: 240, height: 50)
                        .background(Color(.systemBrown))
                        .cornerRadius(12)
                }


                
                Spacer()

                
                NavigationLink {
                    RegistrationView()
                        .navigationBarBackButtonHidden()
                } label: {
                    HStack(spacing: 4) {
                        Text("Create an Account?")
                            .foregroundColor(.brown)
                        Text("Sign up")
                            .fontWeight(.bold)
                            .foregroundColor(.brown)
                    }
                    .font(.footnote)
                }
                .padding(.vertical)

                
            }
        }
    }
}

#Preview {
    LoginView()
}
