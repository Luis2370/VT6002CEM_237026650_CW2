//
//  ChatingArea.swift
//  DirectChat
//
//  Created by user on 13/12/2023.
//

import SwiftUI

struct ChatingArea: View {
    let message: Chatting
    private var isFromcurrentUser: Bool {
        return message.isFromCurrentUser
    }
    var body: some View {
        HStack {
            if isFromcurrentUser {
                Spacer()
                
                Text(message.messageText)
                    .font(.subheadline)
                    .padding()
                    .background(Color(.systemBrown))
                    .foregroundColor(.white)
                    .clipShape(ChatingBubble(isFromCurrentUser: isFromcurrentUser))
                    .frame(maxWidth: UIScreen.main.bounds.width / 1.5, alignment: .trailing)
            } else {
                HStack(alignment: .bottom, spacing: 9) {
                    Image(systemName: "person.circle.fill")
                                                    .resizable()
                                                    .frame(width: 36, height: 36)
                                                    .foregroundColor(.gray)
                    
                    Text(message.messageText)
                        .font(.subheadline)
                        .padding()
                        .background(Color(.systemGray6))
                        .foregroundColor(.brown)
                        .clipShape(ChatingBubble(isFromCurrentUser: isFromcurrentUser))
                        .frame(maxWidth: UIScreen.main.bounds.width / 1.4, alignment: .leading)
                    
                    Spacer()
                }
            }
        }
        .padding(.horizontal, 9)
    }
}

/**#Preview {
    ChatingArea(isFromcurrentUser: false)
}**/
