//
//  ChatingBubble.swift
//  DirectChat
//
//  Created by user on 13/12/2023.
//

import SwiftUI

struct ChatingBubble: Shape {
    let isFromCurrentUser: Bool
    
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect,
                                byRoundingCorners: [
                                    .topLeft,
                                    .topRight,
                                    isFromCurrentUser ? .bottomLeft : .bottomRight],
                                cornerRadii: CGSize(width: 17, height: 17))
        return Path(path.cgPath)
    }
    
}

#Preview {
    ChatingBubble(isFromCurrentUser: true)
}
