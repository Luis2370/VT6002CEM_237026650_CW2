//
//  ChatingView.swift
//  DirectChat
//
//  Created by user on 11/12/2023.
//

import SwiftUI

struct ChatingView: View {
    @StateObject var viewModel: ChattingViewModel
    let user: User
    
    init(user: User) {
        self.user = user
        self._viewModel = StateObject(wrappedValue: ChattingViewModel(user: user))
    }
    
    var body: some View {
        VStack {
            ScrollView {
                VStack {
                    Image(systemName: "person.circle.fill")
                        .resizable()
                        .frame(width: 106, height: 106)
                        .foregroundColor(.gray)
                    
                    VStack(spacing: 5) {
                        Text(user.fullname)
                            .font(.title3)
                            .fontWeight(.semibold)
                        
                        Text("Chating")
                            .font(.footnote)
                            .foregroundColor(.gray)
                    }
                }
                
                
                ForEach(viewModel.messages) { message in
                    ChatingArea(message: message)
                }
                
            }
            Spacer()
            
            
            ZStack(alignment: .trailing) {
                TextField("Chatting...", text: $viewModel.messageText, axis: .vertical)
                    .padding(12)
                    .padding(.trailing, 50)
                    .background(Color(.systemGroupedBackground))
                    .clipShape(Capsule())
                    .font(.subheadline)
                
                Button {
                    viewModel.sendMessage()
                    viewModel.messageText = ""
                } label: {
                    Text("Send")
                        .fontWeight(.semibold)
                        .foregroundColor(.brown)
                }
                .padding(.horizontal)
            }
            .padding()
        }
    }
}

#Preview {
    ChatingView(user: User.MOCK_USER)
}
