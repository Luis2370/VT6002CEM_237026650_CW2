//
//  ProfileView.swift
//  DirectChat
//
//  Created by user on 12/12/2023.
//

import SwiftUI
import PhotosUI
import LocalAuthentication

struct ProfileView: View {
    @StateObject var viewModel = ProfileViewModel()
    @State private var unlocked = false
    @State private var text = "Sign Out"
    
    let user: User
    var body: some View {
        VStack {
            Spacer()
            VStack {
                Spacer()
                PhotosPicker(selection: $viewModel.selectedPic) {
                    if let profileImage = viewModel.profileImage {
                        profileImage
                            .resizable()
                            .scaledToFill()
                            .frame(width: 120, height: 120)
                            .clipShape(Circle())
                    } else {
                        Image(systemName: "person.circle.fill")
                            .resizable()
                            .scaledToFill()
                            .foregroundColor(.brown)
                            .frame(width: 120, height: 120)
                            .clipShape(Circle())
                    }
                    
                }
                    
                Text(user.fullname)
                        .font(.title2)
                        .fontWeight(.bold)
                    
                }
                
                List {
                    
                    Section {
                        Button(text) {
                            authentication()
                        }
                        
                        
                    }
                    .foregroundColor(.red)
                }
                
            }
        }
    func authentication() {
        let context = LAContext()
        var error: NSError?
        
        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
            
            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: "This is for security reason") { success, authenticationError in
                if success {
                    AuthService.shared.signOut()
                } else {
                    text = "Sign Out"
                }
            }
        }
    }
    }



#Preview {
    ProfileView(user: User.MOCK_USER)
}
