//
//  ProfileViewModel.swift
//  DirectChat
//
//  Created by user on 12/12/2023.
//

import SwiftUI
import PhotosUI

class ProfileViewModel: ObservableObject {
    @Published var selectedPic: PhotosPickerItem? {
        didSet { Task { try await loadImage() } }
    }
    
    @Published var profileImage: Image?
    
    func loadImage() async throws {
        guard let item = selectedPic else { return }
        guard let imageData = try await item.loadTransferable(type: Data.self) else {return }
        guard let uiImage = UIImage(data: imageData) else { return }
        self.profileImage = Image(uiImage: uiImage)
    }
}
