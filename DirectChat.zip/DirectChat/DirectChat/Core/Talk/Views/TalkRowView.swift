//
//  TalkRowView.swift
//  DirectChat
//
//  Created by user on 12/12/2023.
//

import SwiftUI

struct TalkRowView: View {
    let message: Chatting
    var body: some View {
        HStack(alignment: .top, spacing: 13) {
            Image(systemName: "person.circle.fill")
                .resizable()
                .frame(width: 63, height: 63)
                .foregroundColor(Color(.systemGray5))
            
            VStack(alignment: .leading, spacing: 5) {
                Text(message.user?.fullname ?? "")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                
                Text(message.messageText)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .lineLimit(/*@START_MENU_TOKEN@*/2/*@END_MENU_TOKEN@*/)
                    .frame(maxWidth: UIScreen.main.bounds.width - 100, alignment: .leading)
            }
            
            HStack {
                Text(message.timestampString)
                
                Image(systemName: "chevron.right")
            }
            .font(.footnote)
            .foregroundColor(.gray)
        }
        .frame(height: 72)
    }
}

/**#Preview {
    TalkRowView()
}**/
