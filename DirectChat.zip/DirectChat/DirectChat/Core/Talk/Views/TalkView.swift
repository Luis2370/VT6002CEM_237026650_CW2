//
//  TalkView.swift
//  DirectChat
//
//  Created by user on 11/12/2023.
//

import SwiftUI

struct TalkView: View {
    @State private var showNewTalkView = false
    @StateObject var viewModel = TalkViewModel()
    @State private var selectedUser: User?
    @State private var showChat = false
    
    
    private var user: User? {
        return viewModel.currentUser
    }
    
    var body: some View {
        NavigationStack {
           
                
                
                List {
                    ActivePartView()
                        .listRowSeparator(.hidden)
                        .listRowInsets(EdgeInsets())
                        .padding(.vertical)
                        .padding(.horizontal, 5)
                    ForEach(viewModel.recentMessages) { message in
                        ZStack {
                            NavigationLink(value: message) {
                                EmptyView()
                            }.opacity(0.0)
                            TalkRowView(message: message)
                        }
                        
                    }
                }
                .listStyle(PlainListStyle())
                
            
            .onChange(of: selectedUser, perform: { newValue in
                showChat = newValue != nil
            })
            .navigationDestination(for: Chatting.self, destination: { message in
                if let user = message.user {
                    ChatingView(user: user)
                }
            })
            .navigationDestination(for: User.self, destination: { user in
                ProfileView(user: user)
            })
            .navigationDestination(isPresented: $showChat, destination: {
                if let user = selectedUser {
                    ChatingView(user: user)
                }
            })
            .fullScreenCover(isPresented: $showNewTalkView, content: {
                NewTalkView(selectedUser: $selectedUser)
            })
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    HStack {
                        NavigationLink(value: user) {
                            Image(systemName: "person.bubble")
                                .resizable()
                                .scaledToFill()
                                .foregroundColor(.brown)
                                .frame(width: 36, height: 36)
                        }
                        
                        Text("Direct Chat")
                            .font(.title)
                            .fontWeight(.semibold)
                            .foregroundColor(.brown)
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showNewTalkView.toggle()
                        selectedUser = nil
                    } label: {
                        Image(systemName: "rectangle.and.pencil.and.ellipsis")
                            .resizable()
                            .frame(width: 50, height: 35)
                            .foregroundStyle(.brown, Color(.systemGray6))
                    }
                }
            }
            
        }
    }
}

#Preview {
    TalkView()
}
