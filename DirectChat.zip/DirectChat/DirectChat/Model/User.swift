//
//  User.swift
//  DirectChat
//
//  Created by user on 18/12/2023.
//

import Foundation
import FirebaseFirestoreSwift

struct User: Codable, Identifiable, Hashable {
    @DocumentID var uid: String?
    let fullname: String
    let email: String
    var profileImageUrl: String?
    
    var id: String {
        return uid ?? NSUUID().uuidString
    }
}

extension User {
    static let MOCK_USER = User(fullname: "Amy Wong", email: "amywong@gmail.com", profileImageUrl: "IMG_0111")
}
