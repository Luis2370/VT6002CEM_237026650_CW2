//
//  ChattingService.swift
//  DirectChat
//
//  Created by user on 29/12/2023.
//

import Foundation
import Firebase

struct ChattingService {
}
