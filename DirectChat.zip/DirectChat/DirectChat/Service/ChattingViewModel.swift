//
//  ChattingViewModel.swift
//  DirectChat
//
//  Created by user on 21/12/2023.
//

import Foundation

class ChattingViewModel: ObservableObject {
    @Published var messageText = ""
    @Published var messages = [Chatting]()

    let service: ChatService
    init(user: User) {
        self.service = ChatService(chatPartner: user)
        observeMessages()
    }
    
    func observeMessages() {
        service.observeMessages() { messages in
            self.messages.append(contentsOf: messages)
        }
    }
    
    func sendMessage() {
        service.sendMessage(messageText)
    }
}
